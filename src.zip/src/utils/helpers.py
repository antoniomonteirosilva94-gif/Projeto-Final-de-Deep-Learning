import os
import json
import random

import numpy as np
import torch
import matplotlib.pyplot as plt
import yaml


def set_seed(seed: int):
    """Fixa sementes para garantir reprodutibilidade."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ensure_dir(path: str):
    """Garante que o diretório do arquivo exista."""
    directory = os.path.dirname(path)
    if directory and not os.path.exists(directory):
        os.makedirs(directory, exist_ok=True)


def save_metrics(metrics: dict, path: str = "results/metrics_pinns.json"):
    """Salva métricas em JSON."""
    ensure_dir(path)
    with open(path, "w") as f:
        json.dump(metrics, f, indent=4)
    print(f"Métricas salvas em: {path}")


def load_config(path: str = "config.yaml") -> dict:
    """Carrega o dicionário de configuração."""
    with open(path, "r") as f:
        return yaml.safe_load(f)


def pot_V(a: torch.Tensor, Lambda: float, V0: float) -> torch.Tensor:
    r"""
    Potencial efetivo do modelo quântico-cosmológico:

        V(a) = 36 a^2 + 12 |Λ| a^4 + 12 a V0 sech^2(a)

    Conforme equações (62)–(63) da dissertação. :contentReference[oaicite:3]{index=3}
    """
    Lambda_abs = abs(Lambda)
    sech_sq = (1.0 / torch.cosh(a)) ** 2
    V_eff = 36.0 * a**2 + 12.0 * Lambda_abs * a**4 + 12.0 * a * V0 * sech_sq
    return V_eff


def plot_loss(losses: dict, path: str = "results/figures/loss_curve.png"):
    """Plota a curva de loss do treinamento."""
    ensure_dir(path)
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot(losses["total"], label="Total Loss")
    ax.plot(losses["edp"], label="EDP Loss")
    ax.plot(losses["cc"], label="CC Loss")
    ax.plot(losses["orto"], label="Ortogonalidade")
    ax.plot(losses["ordenação"], label="Ordenação")

    ax.set_xlabel("Época")
    ax.set_ylabel("Loss")
    ax.set_yscale("log")
    ax.grid(True, linestyle="--", alpha=0.3)
    ax.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=200)
    plt.close(fig)
    print(f"Curva de loss salva em: {path}")


def plot_autofunctions(
    eta_all: torch.Tensor,
    a: torch.Tensor,
    L: float,
    num_states_to_plot: int = 3,
    path: str = "results/figures/autofunctions.png",
):
    """
    Plota as autofunções η_n(a) (normalizadas apenas em amplitude máxima)
    para inspeção qualitativa.
    """
    ensure_dir(path)

    a_np = a.detach().cpu().numpy().flatten()
    eta_np = eta_all.detach().cpu().numpy()

    fig, ax = plt.subplots(figsize=(8, 6))
    for n in range(num_states_to_plot):
        eta_n = eta_np[:, n]
        max_abs = np.max(np.abs(eta_n)) + 1e-12
        eta_n_norm = eta_n / max_abs
        ax.plot(a_np, eta_n_norm, label=f"$\\eta_{n+1}(a)$ (normalizada)")

    ax.set_xlabel("a")
    ax.set_ylabel("$\\eta_n(a)$ (escala arbitrária)")
    ax.set_title(f"Primeiros {num_states_to_plot} autoestados – domínio [0, {L}]")
    ax.grid(True, linestyle="--", alpha=0.3)
    ax.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=200)
    plt.close(fig)
    print(f"Autofunções salvas em: {path}")
