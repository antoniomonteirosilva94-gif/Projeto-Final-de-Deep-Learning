import torch
import torch.nn as nn
from torch.autograd import grad

from src.utils.helpers import pot_V


class SpectrumSolver(nn.Module):
    """
    PINN para resolver o problema de autovalores estacionários
    da equação de Wheeler–DeWitt com N autoestados.

        -η''(a) + V(a) η(a) = 12 E η(a),  a ∈ (0, L)
        η(0) = η(L) = 0

    A saída da rede é (N estados) em paralelo.
    """

    def __init__(
        self,
        L: float,
        num_states: int = 3,
        E_init_values: torch.Tensor | None = None,
        hidden_layers: list[int] = [256, 128, 64, 32],
    ):
        super().__init__()

        self.L = L
        self.num_states = num_states

        # Inicialização dos autovalores E_n (parâmetros treináveis)
        if E_init_values is None:
            # algo espalhado entre 1 e 30 (ajuste fino se quiser)
            E_init_values = torch.linspace(1.0, 30.0, steps=num_states)
        E_init_values = E_init_values.flatten().float()

        self.E_n = nn.Parameter(E_init_values.clone().detach())

        # MLP densa
        layers = []
        in_features = 1
        for h in hidden_layers:
            layers.append(nn.Linear(in_features, h))
            layers.append(nn.Tanh())
            in_features = h
        layers.append(nn.Linear(in_features, num_states))

        self.network = nn.Sequential(*layers)

    def forward_raw(self, a: torch.Tensor) -> torch.Tensor:
        """Saída bruta da MLP (sem impor CC)."""
        return self.network(a)

    def forward(self, a: torch.Tensor) -> torch.Tensor:
        """
        Aplica o truque a(L−a) para impor Dirichlet homogênea:
            η_n(a) = a (L − a) η_n^raw(a)
        """
        a_scaled = a * (self.L - a)
        eta_raw = self.forward_raw(a)
        return a_scaled * eta_raw

    def compute_residual(
        self, a: torch.Tensor, Lambda: float, V0: float
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Calcula o resíduo da EDP para todos os estados simultaneamente:

            R_n(a) = -η_n''(a) + V(a) η_n(a) - 12 E_n η_n(a)

        Retorna:
            R_all: (N_points, num_states)
            eta_all: (N_points, num_states)
        """
        a = a.clone().detach().requires_grad_(True)

        eta_all = self.forward(a)  # (N_points, num_states)
        V_eff = pot_V(a, Lambda, V0)  # (N_points, 1) broadcasting

        R_list = []
        num_states = self.num_states

        for n in range(num_states):
            eta_n = eta_all[:, n : n + 1]  # (N_points, 1)

            # primeira derivada
            d_eta_da = grad(
                eta_n,
                a,
                torch.ones_like(eta_n),
                create_graph=True,
                retain_graph=True,
            )[0]

            # segunda derivada
            d2_eta_da2 = grad(
                d_eta_da,
                a,
                torch.ones_like(d_eta_da),
                create_graph=True,
                retain_graph=True,
            )[0]

            E_n = self.E_n[n]
            R_n = -d2_eta_da2 + V_eff * eta_n - 12.0 * E_n * eta_n
            R_list.append(R_n)

        R_all = torch.cat(R_list, dim=1)
        return R_all, eta_all
